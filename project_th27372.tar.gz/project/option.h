

extern int output_mode;
extern int vf_mode;
